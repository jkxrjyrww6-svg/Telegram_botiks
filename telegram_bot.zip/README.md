# Telegram Bot

## Быстрый старт

### 1. Создание бота
- Найди @BotFather в Telegram
- Отправь `/newbot`
- Придумай имя и username (должен заканчиваться на `bot`)
- **Сохрани токен!**

### 2. Запуск

**На компьютере:**
```bash
pip install -r requirements.txt
cp .env.example .env
# Открой .env и вставь токен
python bot.py
```

**Бесплатный хостинг 24/7:**

1. Зарегистрируйся на [render.com](https://render.com)
2. Создай New Web Service из твоего GitHub репозитория
3. Добавь переменную: `TELEGRAM_BOT_TOKEN` = твой_токен
4. Бот будет работать 24/7!

### 3. Тестирование
Найди бота в Telegram по username и нажми Start!
