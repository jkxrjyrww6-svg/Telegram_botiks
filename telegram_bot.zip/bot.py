"""
Telegram Bot для тестирования на телефоне
"""
import asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, KeyboardButton, ReplyKeyboardMarkup
from aiogram.filters import Command
from dotenv import load_dotenv
import os

load_dotenv()

# Токен бота из .env файла
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

if not BOT_TOKEN:
    raise ValueError(" TELEGRAM_BOT_TOKEN не найден! Добавьте его в файл .env")

# Клавиатура
keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Привет 👋"), KeyboardButton(text="Как дела?")],
        [KeyboardButton(text="Кто ты? 🤔"), KeyboardButton(text="Покажи время 🕐")],
    ],
    resize_keyboard=True
)

# Инициализация бота и диспетчера
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Обработчик команды /start
@dp.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        f"Привет, {message.from_user.first_name}! 👋\n\n"
        "Я тестовый бот! Выбери кнопку ниже или напиши что-нибудь.",
        reply_markup=keyboard
    )

# Обработчик команды /help
@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "📋 Доступные команды:\n"
        "/start - Перезапустить бота\n"
        "/help - Показать эту справку\n\n"
        "Также можешь нажать на кнопки!"
    )

# Обработчик сообщения "Привет"
@dp.message(F.text.lower() == "привет")
async def greet(message: Message):
    await message.answer(f"Привет, {message.from_user.first_name}! Как дела? 😊")

# Обработчик сообщения "Как дела?"
@dp.message(F.text.lower() == "как дела?")
async def how_are_you(message: Message):
    await message.answer("У меня всё отлично! Спасибо, что спросил. А у тебя? 👍")

# Обработчик "Кто ты?"
@dp.message(F.text.lower() == "кто ты?")
async def who_are_you(message: Message):
    await message.answer(
        "Я - простой тестовый бот! 🤖\n"
        "Создан для демонстрации работы Telegram API.\n"
        "Можешь со мной общаться!"
    )

# Обработчик "Покажи время"
@dp.message(F.text.lower() == "покажи время")
async def show_time(message: Message):
    from datetime import datetime
    now = datetime.now().strftime("%H:%M:%S")
    await message.answer(f"🕐 Сейчас время: {now}")

# Обработчик любого другого сообщения
@dp.message()
async def echo(message: Message):
    await message.answer(
        f"Ты написал: {message.text}\n"
        "Я пока не умею отвечать на это, но ты можешь нажать на кнопку! 😊"
    )

# Главная функция
async def main():
    print("🚀 Бот запущен!")
    print("Чтобы остановить бота, нажми Ctrl+C")
    
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Бот остановлен")
